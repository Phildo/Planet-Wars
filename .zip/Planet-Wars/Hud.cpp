#include "Hud.h"


Hud::Hud(void)
{
}


Hud::~Hud(void)
{
}


void Hud::drawMeta(){

}
void Hud::drawMini(){


}