//
//  Flagship.h
//  SpongeBobWars
//
//  Created by Philip Dougherty on 11/23/11.
//  Copyright 2011 UW Madison. All rights reserved.
//
#ifndef H_FLAGSHIP
#define H_FLAGSHIP

#include "Model.h"
#include "Ship.h"
#include "DrawableGeometry.h"

class Flagship
{
public:
    Flagship();
    ~Flagship();
};

#endif