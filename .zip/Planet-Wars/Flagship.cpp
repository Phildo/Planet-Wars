//
//  Flagship.cpp
//  SpongeBobWars
//
//  Created by Philip Dougherty on 11/23/11.
//  Copyright 2011 UW Madison. All rights reserved.
//

#include "Flagship.h"
#include "Model.h"

Flagship::Flagship()
{
    //this->shipType = SHIP_TYPE_FLAGSHIP;
}

Flagship::~Flagship()
{
    
}